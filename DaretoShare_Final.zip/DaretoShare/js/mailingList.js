            
            /*document.addEventListener("DOMContentLoaded",docIsReady);*/
			
			var InfoStore;
            var emailList;
			var readOption;
			var emailEntered = [];
			var userEmail;
			var currentUser;
			var userInformation;
			
			
            // docIsReady function to run after page is loaded
            // docIsReady function parse's out array InfoStore to be used in other functions
            //function docIsReady () {
                
                InfoStore = localStorage.getItem ("infoStore");
                
                if (InfoStore == null) {
				    InfoStore = [];
				}
				else {
					InfoStore = JSON.parse (InfoStore);
				}
				
				currentUser = localStorage.getItem ("currentUser");
				
				if (currentUser === "null") {
					currentUser = [];
				}
				else {
					currentUser = JSON.parse (currentUser);
				}
				
				userInformation = localStorage.getItem ("userInformation");
				
				if (userInformation == null) {
					userInformation = [];
				}
				else {
					userInformation = JSON.parse (userInformation);
				}
				
				
                
            //}
	
            // boolean function to Display email (parse in emailInput value)
			function emailDisplay (emailInput) {    
				// Declaring variables and getting DOM elements
				var emailExist = false; //At first no email match so boolean is false
				// Going through array to check if email entered is the same as the email present in localStorage    
				for (var i = 0; i<InfoStore.length; i++) {
					var email = InfoStore [i];
					if (emailInput == email.name){
						emailExist = true;
						break;
					}
				}
			
			return emailExist;
			}

			function emailAdd () {
				
					var emailInput = document.forms["mailList"]["email"].value;
					var emailfield = document.forms["mailList"]["email"];
					var posAt = emailInput.indexOf ("@");
					var posDot = emailInput.lastIndexOf (".");
					
						if (!emailValidate (emailInput)) {
							
							var emailError = document.getElementById("errorMessage");
							emailError.style.display = "inline";
							emailError.innerHTML = "Please Enter a valid Email Address :(";
							emailfield.focus();
							
						
						}
					
						else {
							
							emailError = document.getElementById("errorMessage");
							emailError.style.display = "none";
							emailfield.blur();
							
							emailList = localStorage.getItem ("infoStore");
							
							if (emailList == null){
								emailList = [];
							}
							else {
								emailList = JSON.parse (emailList);
							}
							
							
							// if statement to make sure the same email is not entered and stored twice
							
							if (!emailDisplay(emailInput)) { 
								
								var checkDialog = confirm("Do you want to subscribe?");
								
								if (checkDialog == true){
									var emailEnter = document.getElementById ("Email");
										 
									var obj = {"name": emailInput};
									emailList.push(obj);
									localStorage.setItem ("infoStore", JSON.stringify (emailList));
									
									var emailObj = {"name": emailInput};
									emailEntered.push(emailObj);
									localStorage.setItem ("currentEmail", JSON.stringify (emailEntered));
									
									window.location.href = "EmailAdd_Success.html";  
								}
								
								else {
									location.reload();
								}
						
					
							}
						
							else {
								var emailObj = {"name": emailInput};
								emailEntered.push(emailObj);
								localStorage.setItem ("currentEmail", JSON.stringify (emailEntered));
								window.location.href = "EmailCheck_Success.html";
							}
					
						}
					
				return emailInput;
			}

			function updateEmail () {
				
				emailUpdate();
				
				
			}
			
			function emailUpdate () {
					var emailInput = document.forms["mailList"]["email"].value;
					var posAt = emailInput.indexOf ("@");
					var posDot = emailInput.lastIndexOf (".");
					
						if (posAt < 1 || posAt +2 >posDot || posDot + 2 >= emailInput.length) {
							var emailError = document.getElementById("errorMessage");
							emailError.style.display = "inline";
							emailError.innerHTML = "Please Enter a valid Email Address :(";
							return false;
							var x = false;
						
						}
					
						else {
							
							emailError = document.getElementById("errorMessage");
							emailError.style.display = "none";
							
							emailList = localStorage.getItem ("infoStore");
							
							if (emailList == null){
								emailList = [];
							}
							else {
								emailList = JSON.parse (emailList);
							}
							
							
							// if statement to make sure the same email is not entered and stored twice
							
							if (!emailDisplay(emailInput)) { 
								
								var checkDialog = confirm("Do you want to update your email?");
								
								if (checkDialog == true){
									var emailEnter = document.getElementById ("Email");
										 
									var obj = {"name": emailInput};
									
									removeupdateEmail(obj);
									
									window.location.href = "EmailAdd_Success.html";
									 
								}
								
								else {
									location.reload();
								}
						
					
							}
						
							else {
								var emailObj = {"name": emailInput};
								emailEntered.push(emailObj);
								localStorage.setItem ("currentEmail", JSON.stringify (emailEntered));
								window.location.href = "EmailCheck_Success.html";
							}
					
						}
			}
        
            function emailUpdateR () {
				var firstTime;
				readOption = firstTime;
				var confirmUpdate = confirm ("Are you sure you want to update your Email?");
				if (confirmUpdate = true) {
					firstTime = false;
					window.location.href = "MailingList_update.html";
				}
				return readOption;
            }
			
			
			function emailHide() {
			
				var unSub = document.getElementById ("unSub");
				var upEmail = document.getElementById ("upEmail");
				
				unSub.style.display = "none";
				upEmail.style.display = "none";
				
				
				
			}

			function removeEmail () {
				userEmail = localStorage.getItem ("currentEmail");
				if (userEmail == null) {
					userEmail = [];
				}
				else {
					userEmail = JSON.parse (userEmail);
				}
				var removeOption = confirm ("Are you sure you want to remove your email?");
                
                if (removeOption == true) {
				for (var i = 0; i<InfoStore.length; i++) {
					if (userEmail[0].name == InfoStore [i].name) {
						InfoStore.splice (i,1);
						localStorage.setItem ("infoStore",JSON.stringify (InfoStore));
						alert ("Email Removed Successfully from mailing List");
						break;
					}
				}
                }
                
                window.location.href = "../../Home.html";
				


				
				
			}
			
			function removeupdateEmail (obj) {
				userEmail = localStorage.getItem ("currentEmail");
				if (userEmail == null) {
					userEmail = [];
				}
				else {
					userEmail = JSON.parse (userEmail);
				}
				
				for (var i = 0; i<InfoStore.length; i++) {
					if (userEmail[0].name == InfoStore [i].name) {
						InfoStore.splice (i,1,obj);
						localStorage.setItem ("infoStore",JSON.stringify (InfoStore));
						alert ("Email in mailing list successfully updated");
						break;
					}
				}	


				
				
			}
			
			function maillistBack() {
				
				window.location.href = "../../Home.html";
				
			}
			
			function updateSuccess () {
				window.location.href = "EmailAdd_Success.html";
			}
			
			function emailValidate (emailInput) {
				var emailFormat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				
				if (emailInput.match (emailFormat)){
					return true
				}
				else {
					return false;
				}
				
			}
			
			function emailFill () {
				
				if (currentUser !== "Admin") { // If Current User is not Admin
					
					if (currentUser.length !== 0) { //If Current User is Logged in
						var userIndex = currentUser;
						var emailInp = document.getElementById ("email");
						var currentuserEmail = userInformation[userIndex].email;
						emailInp.value = currentuserEmail;	
					}
				}
				else if (currentUser === "Admin") {
					window.location.href = "MailingList_Review.html";
				}
				
			}
			
			function emailShow () {
				
				if (currentUser === "Admin") {
				
					for (var i = 0; i < InfoStore.length; i++) { // For loop to loop through array and display all emails
				
						// Element Creation
						var divCreated = document.createElement ("DIV");
						
						// Attribute set and class set
						divCreated.setAttribute ("id", "className");
						divCreated.id = "email"+i;
						divCreated.className = "emailContainer";
						
						// Content Creation
						divCreated.innerHTML = "<p style = 'font-size: 1em' >"
													+"</br>"
													+"<strong>" + InfoStore [i].name +"</strong></p>";
						
						//appendChild
						var yes = document.getElementById ("emailReview");
						yes.appendChild (divCreated);
						
					}
				
				}
				else {
					alert ("You must be logged in as an admin to view emails in mailing list");
				}
			}