var userInformation;
function setUp() {
	userInformation = localStorage.getItem("userInformation");
	
	if(userInformation == null){
		userInformation = [];
		localStorage["userInformation"] = JSON.stringify(userInformation);
	}
	else{
		userInformation = JSON.parse(userInformation);
	}
}

function SaveToStorage(){
	userInformation = JSON.parse(localStorage["userInformation"]);
	console.log(userInformation);
	console.log(typeof userInformation);
	var username = document.getElementById("username").value;
	var userType = document.getElementById("userType").value;
	var contact = document.getElementById("contact").value;
	var email = document.getElementById("email").value;
	var inputPassword = document.getElementById("password").value;
	var confirmPass = document.getElementById("pass").value;
	var telValidate = /[6|8|9][0-9]{7}/;
	var emailValidate = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
	var passValidate = /(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/;
	if (username == "") {
		alert("You have yet to enter a username!");
		return false;
	} else if (contact == "") {
		alert("You have yet to enter your contact number!");
		return false;
	} else if (inputPassword == "") {
		alert("You have yet to enter your password!");
		return false;
	} else if (confirmPass == "") {
		alert("Please confirm your password.");
		return false;
	} else if(!telValidate.test(contact)){
		alert("Please match the requested contact number format! Number must start with 6, 8 or 9, and is 8 digits long.");
		return false;
	} else if(!emailValidate.test(email)){
		alert("Please match the requested email format.");
		return false;
	} else if(!passValidate.test(inputPassword)){
		alert("Please ensure your password is at least 8 digits long and contains one uppercase and one lowercase letter, and a number.");
		return false;
	} else if(inputPassword != confirmPass){
		alert("Please ensure your passwords match!");
		return false;
	} else if(checkExisting(username)){
		alert("Username has been taken! Please choose another username.");
		return false;
	}	
	
	var obj = {"username" : username, "accountType" : userType, "contact" : contact, "email" : email, "password" : confirmPass, "profilePic" : "", "bPic" : ""};
	userInformation.push(obj);
	localStorage.setItem("userInformation", JSON.stringify(userInformation));
	window.location.href = "Login.html";
}
function checkExisting(username){
	var existing = false;
	for(i = 0; i < userInformation.length; i++){
		var obj = userInformation[i];
		if(obj.username == username){
			existing = true;
			break;
		}
	}
	return existing;
}
