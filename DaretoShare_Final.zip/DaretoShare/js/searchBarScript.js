function searchIconIn() {
	var searchEl = document.getElementById("searchImg");
	searchEl.src = "../../images/images_for_events/Search2.png";
}
function searchIconOut() {
	var searchEl = document.getElementById("searchImg");
	searchEl.src = "../../images/images_for_events/Search1.png";
}