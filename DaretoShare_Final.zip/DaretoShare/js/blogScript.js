var topicList;
var topicNum;
var currentUser;
var userInfo;
var postList = [];
var commentList = [];

/**************
TOPIC FUNCTIONS
**************/
function createTopic(){
	topicList = localStorage.getItem("topics");
	if(topicList == null){
		topicList = [];
		localStorage["topics"] = JSON.stringify(topicList);
	}
	else{
		topicList = JSON.parse(topicList);
	}
	if(topicNum == null){
		topicNum = [];
	}
	else{
		topicNum = JSON.parse(topicNum);
	}
}

function getTopic(){
	topicList = JSON.parse(localStorage["topics"]);
	
	var newTop = prompt("Please enter the new topic");
	if(newTop == ""){
		alert("You enter nothing!");
		location.reload(true);
	}
	else if(newTop == null){
		location.reload(true);
	}
	else if(topicList.length > 0){
		if(!checkExistingTop(newTop)){
			var obj = {"topic":newTop};
			var obj2 = {"num":0};
			topicList.push(obj);
			topicNum.push(obj2);
			localStorage.setItem("topics",JSON.stringify(topicList));
			var ans = confirm("New Topic Added!");
			if(ans)
				location.reload(true);
		}
		else
			alert("You entered the same thing!");
	}
	else{
		var obj = {"topic":newTop};
		topicList.push(obj);
		localStorage.setItem("topics",JSON.stringify(topicList));
		var ans = confirm("New Topic Added!");
		if(ans){
			location.reload(true);
		}
	}
}

function checkExistingTop(newTop){
	var existing = false;
	var num = topicList.length;
	for(var i = 0 ; i<num ; i++){
		var obj = topicList[i];
		if (topicList[i].topic == newTop){
			existing = true;
			break;
		}
	}
	return existing;
}
//For New Entry Update(Problem Solved)
function showTopicForm(){
	var topicList = localStorage.getItem("topics");
	if(topicList == null){
		topicList = []
	}
	else{
		topicList = JSON.parse(topicList);
	}
	for(var i=0;i<topicList.length;i++){
		var el = document.getElementById("topic");
		var newTop = document.createElement("option");
		newTop.value = topicList[i].topic;
		newTop.innerHTML = topicList[i].topic;
		el.appendChild(newTop);
	}
}
//For Blog Nav Update(Problem Solved)
function showTopicBlogNav(){
	topicList = localStorage.getItem("topics");
	
	if(topicList == null){
		topicList = []
	}
	else{
		topicList = JSON.parse(topicList);
	}
	for(var i=0;i<topicList.length;i++){
		var el = document.getElementById("blogTopics");
		var newTop = document.createElement("li");
		newTop.id = topicList[i].topic+"Nav";
		newTop.innerHTML ="<a href='Blog.html#"+topicList[i].topic+"Div' id='"+topicList[i].topic+"'>"+topicList[i].topic+"</a>";
		el.appendChild(newTop);
	}
}
//For Blog Div Update(Problem Solved)
function showTopicBlogDiv(){
	topicList = localStorage.getItem("topics");
	
	if(topicList == null){
		topicList = []
	}
	else{
		topicList = JSON.parse(topicList);
	}
	for(var i=0;i<topicList.length;i++){
		var el = document.getElementById("blogTopic");
		var newTop = document.createElement("div");
		newTop.id = topicList[i].topic+"Div";
		newTop.className = "blogpage";
		newTop.innerHTML =	"<h1>"+topicList[i].topic+"</h1>"+
							"<div id='blogSection"+topicList[i].topic+"' class='blogArea'></div>";
		el.appendChild(newTop);
	}
}

/******************
BLOG POST FUNCTIONS
******************/
function createBlogList(){
	postList = localStorage.getItem("posts");
	if(postList == null){
		postList = [];
	}
	else{
		postList = JSON.parse(postList);
	}
}

function getPost(){
	topicList = JSON.parse(localStorage["topics"]);
	currentUser = JSON.parse(localStorage["currentUser"]);
	userInfo = JSON.parse(localStorage["userInformation"]);
	if(currentUser == "Admin"){
		var title = document.getElementById("title").value;
		var name = "Admin";
		var p = document.getElementById("post").value;
		var vid = document.getElementById("video").value;
		var topic = document.getElementById("topic").value;
	}
	else{
		var title = document.getElementById("title").value;
		var name = userInfo[currentUser].username;
		var p = document.getElementById("post").value;
		var vid = document.getElementById("video").value;
		var topic = document.getElementById("topic").value;
	}
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; 
	var yyyy = today.getFullYear();

	if(dd<10) {
		dd='0'+dd
	} 

	if(mm<10) {
		mm='0'+mm
	} 

	today = mm+'/'+dd+'/'+yyyy;
	
	var obj = {"num":postList.length,"title":title,"name":name,"date":today,"post":p,"video":vid,"topic":topic};
	postList.push(obj);
	localStorage.setItem("posts",JSON.stringify(postList));
	var ans = confirm("Blog Post Submitted!");
	if(ans){
		location.href="Blog.html";
	}	
}

function showPost(){
	var postsList = localStorage.getItem("posts");
	topicList = JSON.parse(localStorage["topics"]);
	currentUser = JSON.parse(localStorage["currentUser"]);
	userInfo = JSON.parse(localStorage["userInformation"]);
	if(postList == null){
		postList = [];
	}
	else{
		postList = JSON.parse(postsList);
	}
	var r=0;
	for(var i = 0; i < postList.length; i++){
		for(var j = 0; j<topicList.length;j++){
			if(postList[i].topic == topicList[j].topic){
				if(currentUser != null){
					if(currentUser == "Admin"){
						var postsEntered = document.createElement("div");
						postsEntered.id = postList[i].topic+r;
						postsEntered.className = "Entry";
						
						var vid = document.createElement("div");
						vid.classname = "video";
						vid.innerHTML = postList[i].video;	
						
						postsEntered.innerHTML =	"<div class='blogInfo'>"+
													"<h3>"+postList[i].title+"</h3>"+"</br>"+
													"<h4>By: "+postList[i].name+"</h4>"+
													"<p>"+postList[i].date+"</p>"+
													"<p>"+postList[i].post+"</p>"+
													"</div>"+
													"<p style='float:right;cursor:pointer' class='deleteEditBtn' onclick='sendInfoToEditPost("+postList[i].num+")'>Edit</p>"+
													"<p style='float:right;cursor:pointer' class='deleteEditBtn' onclick='deletePost("+postList[i].num+")'>Delete</p>"+
													vid.innerHTML+
													"<div id = 'commentSection"+postsEntered.id+"' class = 'commentArea'></div>"+
													"<div id = 'inputComment'>"+
														"<label for = 'request'>Leave a comment or feedback!</label><br/>"+
														"<textarea id='comment"+postsEntered.id+"' rows = '2' cols = '50'></textarea>"+
														"<button class = 'commentButton' onclick = 'getComment("+postsEntered.id+")'>Post</button>"+
													"</div>"+
													"<dialog id = 'commentDialog'>"+
														"<div id = 'editComment'>"+
															"<p>"+
																"<label for = 'request';style = 'font-size: 1.4em'></label><br/>"+
																"<textarea id = 'EditingComment' rows = '7' cols = '70' placeholder = 'Edit your comment!' style = '1.4em'/></textarea>"+
															"</p>"+
															"<p>"+
																"<button id = 'Save' onclick = 'SaveComment()'>Save</button>"+
															"</p>"+
														"</div>"+
													"</dialog>";
						var el = document.getElementById("blogSection"+topicList[j].topic);
						el.appendChild(postsEntered);
						r++;
					} 
					else if(userInfo[currentUser].accountType == "Student" || userInfo[currentUser].accountType == "Educator"){
						if(userInfo[currentUser].username == postList[i].name){
							var postsEntered = document.createElement("div");
							postsEntered.id = postList[i].topic+r;
							postsEntered.className = "Entry";
							
							var vid = document.createElement("div");
							vid.classname = "video";
							vid.innerHTML = postList[i].video;	
							
							postsEntered.innerHTML =	"<div class='blogInfo'>"+
														"<h3>"+postList[i].title+"</h3>"+"</br>"+
														"<h4>By: You</h4>"+
														"<p>"+postList[i].date+"</p>"+
														"<p>"+postList[i].post+"</p>"+
														"</div>"+
														"<p style='float:right;cursor:pointer' class='deleteEditBtn' onclick='sendInfoToEditPost("+postList[i].num+")'>Edit</p>"+
														"<p style='float:right;cursor:pointer' class='deleteEditBtn' onclick='deletePost("+postList[i].num+")'>Delete</p>"+
														vid.innerHTML+
														"<div id = 'commentSection"+postsEntered.id+"' class = 'commentArea'></div>"+
														"<div id = 'inputComment'>"+
															"<label for = 'request'>Leave a comment or feedback!</label><br/>"+
															"<textarea id='comment"+postsEntered.id+"' rows = '2' cols = '50'></textarea>"+
															"<button class = 'commentButton' onclick = 'getComment("+postsEntered.id+")'>Post</button>"+
														"</div>"+
														"<dialog id = 'commentDialog'>"+
															"<div id = 'editComment'>"+
																"<p>"+
																	"<label for = 'request';style = 'font-size: 1.4em'></label><br/>"+
																	"<textarea id = 'EditingComment' rows = '7' cols = '70' placeholder = 'Edit your comment!' style = '1.4em'/></textarea>"+
																"</p>"+
																"<p>"+
																	"<button id = 'Save' onclick = 'SaveComment("+postList[i].num+")'>Save</button>"+
																"</p>"+
															"</div>"+
														"</dialog>";
							var el = document.getElementById("blogSection"+topicList[j].topic);
							el.appendChild(postsEntered);
							r++;
						}
						else{
							var postsEntered = document.createElement("div");
							postsEntered.id = postList[i].topic+r;
							postsEntered.className = "Entry";
							
							var vid = document.createElement("div");
							vid.classname = "video";
							vid.innerHTML = postList[i].video;	
							
							postsEntered.innerHTML =	"<div class='blogInfo'>"+
														"<h3>"+postList[i].title+"</h3>"+"</br>"+
														"<h4>By: "+postList[i].name+"</h4>"+
														"<p>"+postList[i].date+"</p>"+
														"<p>"+postList[i].post+"</p>"+
														"</div>"+
														vid.innerHTML+
														"<div id = 'commentSection"+postsEntered.id+"' class = 'commentArea'></div>"+
														"<div id = 'inputComment'>"+
															"<label for = 'request'>Leave a comment or feedback!</label><br/>"+
															"<textarea id='comment"+postsEntered.id+"' rows = '2' cols = '50'></textarea>"+
															"<button class = 'commentButton' onclick = 'getComment("+postsEntered.id+")'>Post</button>"+
														"</div>"+
														"<dialog id = 'commentDialog'>"+
															"<div id = 'editComment'>"+
																"<p>"+
																	"<label for = 'request';style = 'font-size: 1.4em'></label><br/>"+
																	"<textarea id = 'EditingComment' rows = '7' cols = '70' placeholder = 'Edit your comment!' style = '1.4em'/></textarea>"+
																"</p>"+
																"<p>"+
																	"<button id = 'Save' onclick = 'SaveComment()'>Save</button>"+
																"</p>"+
															"</div>"+
														"</dialog>";
							var el = document.getElementById("blogSection"+topicList[j].topic);
							el.appendChild(postsEntered);
							r++;
						}
					}
				}
				else{
					var postsEntered = document.createElement("div");
							postsEntered.id = postList[i].topic+r;
							postsEntered.className = "Entry";
							
							var vid = document.createElement("div");
							vid.classname = "video";
							vid.innerHTML = postList[i].video;	
							
							postsEntered.innerHTML =	"<div class='blogInfo'>"+
														"<h3>"+postList[i].title+"</h3>"+"</br>"+
														"<h4>By: "+postList[i].name+"</h4>"+
														"<p>"+postList[i].date+"</p>"+
														"<p>"+postList[i].post+"</p>"+
														"</div>"+
														vid.innerHTML+
														"<div id = 'commentSection"+postsEntered.id+"' class = 'commentArea'></div>"+
														"<dialog id = 'commentDialog'>"+
															"<div id = 'editComment'>"+
																"<p>"+
																	"<label for = 'request';style = 'font-size: 1.4em'></label><br/>"+
																	"<textarea id = 'EditingComment' rows = '7' cols = '70' placeholder = 'Edit your comment!' style = '1.4em'/></textarea>"+
																"</p>"+
																"<p>"+
																	"<button id = 'Save' onclick = 'SaveComment()'>Save</button>"+
																"</p>"+
															"</div>"+
														"</dialog>";
							var el = document.getElementById("blogSection"+topicList[j].topic);
							el.appendChild(postsEntered);
							r++;
				}
			}
		}
	}
}

function sendInfoToEditPost(divOfInterest){
	var divId = divOfInterest;
	console.log(divId);
	var obj = {"num":divId};
	localStorage["specialIndex"] = JSON.stringify(obj);
	window.location.href = "EditingBlog.html";
}

function retrieveInfo(){
	var postList = JSON.parse(localStorage["posts"]);
	var specialNum = JSON.parse(localStorage["specialIndex"]);
	document.getElementById("post").value = postList[specialNum.num].post;
	document.getElementById("video").value = postList[specialNum.num].video;
	document.getElementById("topic").value = postList[specialNum.num].topic;
	document.getElementById("title").value = postList[specialNum.num].title;
}

function editPost(){
	currentUser = JSON.parse(localStorage["currentUser"]);
	userInfo = JSON.parse(localStorage["userInformation"]);
	if(currentUser == "Admin"){
		var name = "Admin";
	}
	else{
		var name = userInfo[currentUser].username;
	}
	var usersAns = confirm("Are you sure you want to edit this post? This process is not reversible.");
	if (usersAns == true) {
		var trueOrfalse;
		var postList = JSON.parse(localStorage["posts"]); 
		var specialNum = JSON.parse(localStorage["specialIndex"]);
		var title = document.getElementById("title").value;
		var p = document.getElementById("post").value;
		var vid = document.getElementById("video").value;
		var topic = document.getElementById("topic").value;
		var today = new Date();
		var dd = today.getDate();
		var mm = today.getMonth()+1; 
		var yyyy = today.getFullYear();

		if(dd<10) {
			dd='0'+dd
		} 

		if(mm<10) {
			mm='0'+mm
		} 

		today = mm+'/'+dd+'/'+yyyy;
	
		var obj = {"num":specialNum.num,"title":title,"name":name,"date":today,"post":p,"video":vid,"topic":topic};
		postList[specialNum.num] = obj;
		localStorage["posts"] = JSON.stringify(postList);
		window.location.href = "Blog.html";
	}
}

function deletePost(divOfInterest){
	var ans = confirm("Are you sure you want to delete your blog post? This process is irrevisible!");
	var postsArea = JSON.parse(localStorage["posts"]);
	if(ans)
	{
		var divId = divOfInterest;
		//postsArea[divId].style.display = "none";
		//var i = divId.charAt(divId.length - 1);
		postsArea.splice(divId, 1);
		localStorage["posts"] = JSON.stringify(postsArea);
		alert("Your post has been deleted");
		location.reload();
	}				
}

/****************
COMMENTS FUNCTION
****************/
function createCommentList(){
	commentList = localStorage.getItem("comments");
	if(commentList == null)
	{
		commentList = [];
	}
	else{
		commentList = JSON.parse(commentList);
	}
}

function getComment(divOfInterest){
	commentList = localStorage.getItem("comments");
	currentUser = JSON.parse(localStorage["currentUser"]);
	userInfo = JSON.parse(localStorage["userInformation"]);
	var count = 0;
	if(currentUser == "Admin"){
		var name = "Admin";
		var accType = "Admin";
	}
	else{
		var name = userInfo[currentUser].username;
		var accType = userInfo[currentUser].accountType;
	}
	if(commentList == null)
	{
		commentList = [];
	}
	else{
		commentList = JSON.parse(commentList);
	}
	for(var i=0;i<commentList.length;i++){
		if(commentList[i].name == name){
			count++;
		}
	}
	var comment = document.getElementById("comment"+divOfInterest.id).value;
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; 
	var yyyy = today.getFullYear();

	if(dd<10) {
		dd='0'+dd
	} 

	if(mm<10) {
		mm='0'+mm
	} 

	today = mm+'/'+dd+'/'+yyyy;
	if(comment == ""){
		alert("You have not entered anything!");
	}
	else if(count>2){
		if(checkExistingCom(comment,divOfInterest.id,name)){
			var obj = {"comment":comment,"post":divOfInterest.id,"date":today,"name":name,"accType":accType};
			commentList.push(obj);
			localStorage.setItem("comments",JSON.stringify(commentList));
			var ans = confirm("Comment Submitted!");
			if(ans)
				location.reload(true);
		}
		else
			alert("You entered the same thing!");
	}		
	else{
		var obj = {"comment":comment,"post":divOfInterest.id,"date":today,"name":name,"accType":accType, "num":commentList.length};
		commentList.push(obj);
		localStorage.setItem("comments",JSON.stringify(commentList));
		var ans = confirm("Comment Submitted!");
		if(ans)
			location.reload(true);
		else
			location.reload(true);
	}
}

function checkExistingCom(comment,topic,name){
	commentList = localStorage.getItem("comments");
	commentList = JSON.parse(commentList);
	var existing = true;
	var num = commentList.length-1;
	for(var i = 1 ; i<=num ; i++){
		var obj = commentList[num-i];
		if(obj.post == topic){
			if(obj.name == name){
				if (obj.comment == comment){
					existing = false;
					break;
				}
			}
		}
	}
	return existing;
}

function showComment(){
	commentList = localStorage.getItem("comments");
	postList = localStorage.getItem("posts");
	postList = JSON.parse(postList);
	currentUser = JSON.parse(localStorage["currentUser"]);
	userInfo = JSON.parse(localStorage["userInformation"]);
	if(commentList == null){
		commentList = [];
	}
	else{
		commentList = JSON.parse(commentList);
	}
	for(var i = 0; i < commentList.length; i++){
		for(var j=0;j<postList.length;j++){
			if(commentList[i].post == postList[j].topic+postList[j].num){
				if(currentUser != null)
				{
					if(currentUser == "Admin"){
						if(currentUser == commentList[i].name){
							var commentsEntered = document.createElement("div");
							commentsEntered.id = postList[j].topic+postList[j].num+"_"+i;
							commentsEntered.className = "comment";
							commentsEntered.value = commentList[i].comment;
							commentsEntered.innerHTML = "<h4>You:&nbsp</h4><abbr title='"+commentList[i].date+"'>"+commentList[i].comment+"</abbr><br/>"+
							"<p class='deleteEditBtn' onclick='DisplayEdit(this.parentNode)'>Edit</p>"+
							"<p class='deleteEditBtn' onclick='DeleteComment(this.parentNode)'>Delete</p>";
							var el = document.getElementById("commentSection"+postList[j].topic+postList[j].num);
							el.appendChild(commentsEntered);
							break;
						}
						else{
							var commentsEntered = document.createElement("div");
							commentsEntered.id = postList[j].topic+postList[j].num+"_"+i;
							commentsEntered.className = "comment";
							commentsEntered.value = commentList[i].comment;
							commentsEntered.innerHTML = "<abbr title="+commentList[i].accType+"><h4>"+commentList[i].name+":&nbsp</h4></abbr><abbr title='"+commentList[i].date+"'>"+commentList[i].comment+"</abbr><br/>"+
							"<p class='deleteEditBtn' onclick='DisplayEdit(this.parentNode)'>Edit</p>"+
							"<p class='deleteEditBtn' onclick='DeleteComment(this.parentNode)'>Delete</p>";
							var el = document.getElementById("commentSection"+postList[j].topic+postList[j].num);
							el.appendChild(commentsEntered);
							break;
						}
					}
					else if(userInfo[currentUser].accountType == "Student" || userInfo[currentUser].accountType == "Educator"){
						if(userInfo[currentUser].username == commentList[i].name){
							var commentsEntered = document.createElement("div");
							commentsEntered.id = postList[j].topic+postList[j].num+"_"+i;
							commentsEntered.className = "comment";
							commentsEntered.value = commentList[i].comment;
							commentsEntered.innerHTML = "<h4>You:&nbsp</h4><abbr title='"+commentList[i].date+"'>"+commentList[i].comment+"</abbr><br/>"+
							"<p class='deleteEditBtn' onclick='DisplayEdit(this.parentNode)'>Edit</p>"+
							"<p class='deleteEditBtn' onclick='DeleteComment(this.parentNode)'>Delete</p>";
							var el = document.getElementById("commentSection"+postList[j].topic+postList[j].num);
							el.appendChild(commentsEntered);
							break;
						}
						else{
							var commentsEntered = document.createElement("div");
							commentsEntered.id = postList[j].topic+postList[j].num+"_"+i;
							commentsEntered.className = "comment";
							commentsEntered.value = commentList[i].comment;
							commentsEntered.innerHTML = "<abbr title="+commentList[i].accType+"><h4>"+commentList[i].name+":&nbsp</h4></abbr><abbr title='"+commentList[i].date+"'>"+commentList[i].comment+"</abbr><br/>"+
							"<p class = 'deleteEditBtn' onclick = 'toFeedback()'>Flag</p>";
							var el = document.getElementById("commentSection"+postList[j].topic+postList[j].num);
							el.appendChild(commentsEntered);
							break;
						}
					}
				}
				else{
					var commentsEntered = document.createElement("div");
							commentsEntered.id = postList[j].topic+postList[j].num+"_"+i;
							commentsEntered.className = "comment";
							commentsEntered.value = commentList[i].comment;
							commentsEntered.innerHTML = "<abbr title="+commentList[i].accType+"><h4>"+commentList[i].name+":&nbsp</h4></abbr><abbr title='"+commentList[i].date+"'>"+commentList[i].comment+"</abbr><br/>"+
							"<p class = 'deleteEditBtn' onclick = 'toFeedback()'>Flag</p>";
							var el = document.getElementById("commentSection"+postList[j].topic+postList[j].num);
							el.appendChild(commentsEntered);
							break;
				}
			}
		}
	}
}

function DisplayEdit(divOfInterest) {
	commentList = localStorage.getItem("comments");
	document.getElementById("commentDialog").showModal();
	var commentsArea = JSON.parse(localStorage["comments"]);
	console.log(divOfInterest.num)
	var specialIndex = divOfInterest.id.split("_").pop();
	localStorage["specialIndex"] = JSON.stringify(specialIndex);
	//var specialComment = JSON.parse(localStorage["specialIndex"]);
	document.getElementById("EditingComment").value = document.getElementById(divOfInterest.id).value;//commentsArea[specialComment].comment;
}

function SaveComment(divOfInterest) {
	num = divOfInterest.num
	var commentsArray = JSON.parse(localStorage["comments"]);
	currentUser = JSON.parse(localStorage["currentUser"]);
	userInfo = JSON.parse(localStorage["userInformation"]);
	var specialComment = JSON.parse(localStorage["specialIndex"]);
	var latestComment = document.getElementById("EditingComment").value;
	console.log(latestComment);
	
	var obj = latestComment;
	commentsArray[specialComment].comment = obj;
	localStorage["comments"] = JSON.stringify(commentsArray);
	alert("Your comment has been edited");
	location.reload();
}						
			
function DeleteComment(divOfInterest) {
	confirm("Are you sure you want to delete comment?");
	divOfInterest.style.display = "none";
	var divId = divOfInterest.id;
	var i = divId.split("_").pop();	
	var commentsArea = JSON.parse(localStorage["comments"]);
	commentsArea.splice(i, 1);
	localStorage["comments"] = JSON.stringify(commentsArea);
	alert("Your comment has been deleted");			
}

/**************
Other Functions
**************/
function checkBlogNav(){
	topicList = JSON.parse(localStorage["topics"]);
	currentUser = JSON.parse(localStorage["currentUser"]);
	if(currentUser != null){
		document.getElementById("loginOut").innerHTML = "<a onclick='logout()'>Log Out</a>";
		document.getElementById("profile").style.display = "block";
	}
	else{
		document.getElementById("loginOut").innerHTML =	"<a href='../Administration/Login.html'>Login</a>";
		document.getElementById("profile").style.display = "none";												
	}
}

function chkIfLogin(){
	currentUser = JSON.parse(localStorage["currentUser"]);
	userInfo = JSON.parse(localStorage["userInformation"]);
	if(currentUser == null)
	{
		alert("Login to Create New Entry!");
		location.href="../Administration/Login.html";
	}
	else{
		location.href="NewEntry.html";
	}
}

function toFeedback(){
	location.href="../Feedback/feedback.html";
}