var commentsArea;
var currentUser;
var userInformation;
function docIsReady() {			   
	commentsArea=localStorage.getItem("commentsArea");
	
	//Double checking for commentsArea []
	if (commentsArea == null) {
		commentsArea = [];
	}
	else {
		commentsArea = JSON.parse(commentsArea);
	}
	
	//Codes for the Profile, Login and Logout Buttons in Header
	currentUser = JSON.parse(localStorage["currentUser"]);
	currentUser = localStorage.getItem("currentUser");
	if (currentUser === "null"){
		currentUser = [];
		document.getElementById("login").style.display = "inline";
		return false;
     }
	else {
		currentUser = JSON.parse(currentUser);
		document.getElementById("login").style.display = "none";
		document.getElementById("logout").style.display = "inline";
		document.getElementById("profile").style.display = "inline";
		return false;
	}
}

function GetComment(){ 
	/***********Retrieve Info from Local Storage***********/
	//For Comments
	commentsArea = localStorage.getItem("commentsArea");
	//For Current User Status
	currentUser = JSON.parse(localStorage["currentUser"]);
	//For Current User Information
	userInfo = JSON.parse(localStorage["userInformation"]);
	
	//Variable for Checking Num of Comments
	var count = 0; 
	
	if(currentUser == "Admin"){
		var name = "Admin";
		var accType = "Admin";
	}
	else{
		var name = userInfo[currentUser].username;
		var accType = userInfo[currentUser].accountType;
	}
	
	//Double checking for commentsArea []
	if(commentsArea == null) {
		commentsArea = [];
	}
	else {
		commentsArea = JSON.parse(commentsArea);
	}
	
	//Counting num of Comments by Same Person
	for(var i=0;i<commentsArea.length;i++){
		if(commentsArea[i].username == name){
			count++;
		}
	}	
	var comment = document.getElementById("Comment").value;
	
	//Checking Comment Box
	if(comment == ""){
		alert("You have not entered anything!");
	}
	
	//Checking If There is More Than 1 Comment By The Same Person
	else if(count > 1){
		
		//Checking Existing Comments
		if(CheckExisting(comment,name)){
			
			//Creating and Pushing Comments into commentsArea[]
			var commentObj = {"username": name,"comment": comment, "accountType": accType};
			commentsArea.push(commentObj);
			localStorage.setItem("commentsArea",JSON.stringify(commentsArea));
			var ans = confirm("Comment Submitted!");
			if(ans)
				location.reload(true);
			else
				location.reload(true);
			}
		else{
			alert("You entered the same thing!");
		}
	}
	
	//Creating and Pushing Comments into commentsArea[]
	else{
		var commentObj = {"username": name,"comment": comment, "accountType": accType};
		commentsArea.push(commentObj);
		localStorage.setItem("commentsArea",JSON.stringify(commentsArea));
		var ans = confirm("Comment Submitted!");
		if(ans)
			location.reload(true);
		else
			location.reload(true);
	}
}

//Checking Existing Comments
function CheckExisting(comment,name){
	/***********Retrieve Info from Local Storage***********/
	commentsArea = localStorage.getItem("commentsArea");
	commentsArea = JSON.parse(commentsArea);
	
	//Creating Variables Needed
	var existing = true;
	var num = commentsArea.length-1;
	var test = 5;
	
	if(commentsArea.length<5){
		test = num;
	}
	else{
		test = 5;
	}
	
	//Checking for Same Comment By The Same Person
	for(var i = 1 ; i<=test ; i++){
		var obj = commentsArea[num-i];
		
		//Check for Same Name
		if(obj.username == name){
			
			//Check for Same Comment
			if (obj.comment == comment){
				
				//Initialize Variable to be Returned
				existing = false;
				break;
			}
		}
	}
	return existing;
}

function ShowComment(){
	/***********Retrieve Info from Local Storage***********/
	//For Comments
	commentsArea = localStorage.getItem("commentsArea");
	//For Current User Status
	currentUser = JSON.parse(localStorage["currentUser"]);
	//For Current User Information
	userInfo = JSON.parse(localStorage["userInformation"]);
	
	//Double Checking CommentsArea []
	if(commentsArea == null)
	{
		commentsArea = [];
	}
	else{
		commentsArea = JSON.parse(commentsArea);
	}
	
	//Beginning of Displaying Comments (For Loop)
	for(var i = 0 ; i < commentsArea.length ; i++){
		
		//Checking for Login User
		if(currentUser != null){
			
			//Checking for Admin
			if(currentUser == "Admin"){
				
				//Checking if Comment was By Current User
				if(currentUser == commentsArea[i].username){ //If yes, display Admin 
					var commentsEntered = document.createElement("div");
					commentsEntered.setAttribute("id", i);
					commentsEntered.className = "comments";
					commentsEntered.innerHTML = commentsArea[i].comment + "<br/><input type='button' value='Edit' id='Edit' class='big' onclick='DisplayEdit(this.parentNode)'>&nbsp;<input type='button' id='Delete' class='big' value='Delete' onClick ='DeleteComment(this.parentNode)'><br/><p>Written by: Admin</p>";
					var onecomment = document.getElementById("CommentSection");
					onecomment.appendChild(commentsEntered);
				}
				else{ //If No, Display Author Name
					var commentsEntered = document.createElement("div");
					commentsEntered.setAttribute("id", i);
					commentsEntered.className = "comments";
					commentsEntered.innerHTML = commentsArea[i].comment + "<br/><input type='button' value='Edit' id='Edit' class='big' onclick='DisplayEdit(this.parentNode)'>&nbsp;<input type='button' id='Delete' class='big' value='Delete' onClick ='DeleteComment(this.parentNode)'><br/><p>Written by: "+commentsArea[i].username+"</p>";
					var onecomment = document.getElementById("CommentSection");
					onecomment.appendChild(commentsEntered);
				}
			}
			else if(userInfo[currentUser].accountType == "Student" || userInfo[currentUser].accountType == "Educator"){
				
				//Checking if Comment was By Current User
				if(userInfo[currentUser].username == commentsArea[i].username){ //If Yes, Display "You", and add in Edit, Delete buttons
					var commentsEntered = document.createElement("div");
					commentsEntered.setAttribute("id", i);
					commentsEntered.className = "comments";
					commentsEntered.innerHTML = commentsArea[i].comment + "<br/><input type='button' value='Edit' id='Edit' class='big' onclick='DisplayEdit(this.parentNode)'>&nbsp;<input type='button' id='Delete' class='big' value='Delete' onClick ='DeleteComment(this.parentNode)'><br/><p>Written by: You</p>";
					var onecomment = document.getElementById("CommentSection");
					onecomment.appendChild(commentsEntered);
				}
				else{ //If No, Display Author Name, without buttons
					var commentsEntered = document.createElement("div");
					commentsEntered.setAttribute("id", i);
					commentsEntered.className = "comments";
					commentsEntered.innerHTML = commentsArea[i].comment + "<br/><br/><br/><p>Written by: "+commentsArea[i].username+"</p>";
					var onecomment = document.getElementById("CommentSection");
					onecomment.appendChild(commentsEntered);
				}
			}
		}
		
		//For Guest Preview
		else{
			var commentsEntered = document.createElement("div");
			commentsEntered.setAttribute("id", i);
			commentsEntered.className = "comments";
			commentsEntered.innerHTML = commentsArea[i].comment + "<br/><br/><br/><p>Written by: "+commentsArea[i].username+"</p>";
			var onecomment = document.getElementById("CommentSection");
			onecomment.appendChild(commentsEntered);
		}
	}
}

function DisplayEdit(divOfInterest) {
	/***********Displays Modal for User to Edit Specific Comment***********/
	commentsArea=localStorage.getItem("commentsArea");
	//Displays the Overlay with Text Area for User to Edit Comment
	document.getElementById("commentDialog").showModal();
	var commentsArea = JSON.parse(localStorage["commentsArea"]);
	console.log(divOfInterest.id);
	//Allocates the Number of the Specific Comment to Variable
	var specialIndex = parseInt(divOfInterest.id);
	localStorage["specialIndex"] = JSON.stringify(specialIndex);
    //Inserts User's Older Version Comment into the Text Area Comment Box for faster Editing
	document.getElementById("EditingComment").value = commentsArea[specialIndex].comment;	
}	

function SaveComment() {
	/***********Updates the Specific Comment on the page***********/
	commentsArea=localStorage.getItem("commentsArea");
	var commentsArray = JSON.parse(localStorage["commentsArea"]);
	//For Current User Status
	currentUser = JSON.parse(localStorage["currentUser"]);
	//For Current User Information
	userInformation = JSON.parse(localStorage["userInformation"]);
	var specialComment = JSON.parse(localStorage["specialIndex"]);
	//Assigns User's Edited Comment to Variable
	var latestComment = document.getElementById("EditingComment").value;
	commentsArray[specialComment].comment = latestComment;
	localStorage["commentsArea"] = JSON.stringify(commentsArray);
	alert("The comment has been edited");
	location.reload();
}

function DeleteComment(divOfInterest) {
	/***********Deletes the Comment from the page***********/
	confirm("Are you sure you want to delete the comment?");
	divOfInterest.style.display = "none";
	//Selects the Specific Comment
	var divId = divOfInterest.id;
	var i = divId.charAt(divId.length - 1);
	commentsArea = JSON.parse(localStorage["commentsArea"]);
	//Removes the Specific Comment specified by User
	commentsArea.splice(i, 1);
	localStorage["commentsArea"] = JSON.stringify(commentsArea);
	alert("Your comment has been deleted");
	location.reload();
}

function CheckIfLoggedIn() {
	/***********Checks to see if Person Viewing is Guest or User***********/
	//For Current User Status
	currentUser = JSON.parse(localStorage["currentUser"]);
	//For Current User Information
	userInformation = JSON.parse(localStorage["userInformation"]);
	//Checks If Guest is present
	if(currentUser == null) {
	   //Hides the TextArea Comment Box to prevent Guest from entering Comments
	   document.getElementById("InputComment").style.display = "none";
	   alert("Welcome Guest. You are not logged in! Log in to use comments");
	}		
}

function AlternateColors() {
	/***********Sets Alternating Colors for Comments***********/
	var colorcomments = document.getElementsByClassName("comments");
    for (var i = 0; i < colorcomments.length; i++) {
	colorcomments[i].classList.add(i % 2 === 0 ? "even" : "odd");
	colorcomments[i].style["background-color"] = i % 2 === 0 ? "#A0DB8E" : "#D4FFE1";
	}
}
