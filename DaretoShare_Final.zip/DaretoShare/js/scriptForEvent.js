/*****************************************************************************************************************************
	Library Name	:	Script For Event (Events Section of Website)
	Author			:	Harish S/O Balamurugan
	Admin No.		:	160390R
	Purpose			:	To organise the JavaScript codes required for Events Section for readability
*****************************************************************************************************************************/
var eventsList;
var reasonsList;
var locationArray = ['../../Images/location/TableTennisCourt.jpg', '../../Images/location/BadmintonCourt.jpg', '../../Images/location/LTL-1.jpg', '../../Images/location/TutorialRoom.jpg', '../../Images/location/Stadium.jpg', '../../Images/location/SwimmingPool.jpg'];
/*****************************************************************************************************************************
	On DOMContentLoaded, check 'status' of eventsList inside userInformation inside localStorage
	If nothing inside eventsList, create an empty array;
	Otherwise, parse eventsList for 'future manipulation'
*****************************************************************************************************************************/
function docIsReady() {
	eventsList = localStorage.getItem("eventsList");
	if (eventsList == null) {
		eventsList = [];
		localStorage["eventsList"] = JSON.stringify(eventsList);
	} else {	
		eventsList = JSON.parse(eventsList);
	}
}
/*****************************************************************************************************************************
	To log out of daretoshare events section
*****************************************************************************************************************************/
function logOutOfPage() {
	var value = JSON.parse(localStorage["currentUser"]);
	value = null;
	localStorage.setItem("currentUser", JSON.stringify(value));
	localStorage.removeItem("Superuser");
	alert("You have successfully logged out of your account.");
	location.reload();
}
/*****************************************************************************************************************************
	Check if user is logged in
*****************************************************************************************************************************/
function loggedInOrNot(el) {
	var currentUser = JSON.parse(localStorage["currentUser"]);
	if (currentUser != null) {
		el.innerHTML = "<a style='cursor: pointer;' onclick='logOutOfPage()'>Logout</a>";
	} else {
		return false;
	}
}
function getLocationSelected(imageSelected) {
	var locationSuggested = document.getElementById("location");
	locationSuggested.innerHTML = "Location: " + imageSelected.alt;
}
function suggestLocation() {
	var audienceIndex = document.getElementById("audienceSize").selectedIndex;
	if (audienceIndex === 0) {
		var usersAns = confirm("Have you selected the audience size?");
		if (usersAns === false) {
			return false;
		}
	}
	var locationSuggested = document.getElementById("location");
	if (audienceIndex == 0 || audienceIndex == 1) {
		locationSuggested.innerHTML = "<img class='suggestions' src=" + locationArray[0] + " alt='Sports Hall' title='Sports Hall' onclick='getLocationSelected(this)'>" + 
										"&nbsp;&nbsp;&nbsp;" + 
										"<img class='suggestions' src=" + locationArray[1] + " alt='Sports Hall' title='Sports Hall' onclick='getLocationSelected(this)'>";
	} else if (audienceIndex >= 2 && audienceIndex <= 4) {
		locationSuggested.innerHTML = "<img class='suggestions' src=" + locationArray[2] + " alt='LTL-1' title='LTL-1' onclick='getLocationSelected(this)'>" + 
										"&nbsp;&nbsp;&nbsp;" + 
										"<img class='suggestions' src=" + locationArray[3] + " alt='Tutorial Room' title='Tutorial Room' onclick='getLocationSelected(this)'>";
	} else {
		locationSuggested.innerHTML = "<img class='suggestions' src=" + locationArray[4] + " alt='Sports Stadium' title='Sports Stadium' onclick='getLocationSelected(this)'>" + 
										"&nbsp;&nbsp;&nbsp;" + 
										"<img class='suggestions' src=" + locationArray[5] + " alt='Swimming Pool' title='Swimming Pool' onclick='getLocationSelected(this)'>";
	}
}
/*****************************************************************************************************************************
	Set max='2' for duration (input type='number') in CreateEvent.html and EditingEvent.html
*****************************************************************************************************************************/
function setMaxDuration() {
	var startTime = document.getElementById("startTime").value;
	var duration = document.getElementById("duration");
	anotherTimeArray = startTime.split(":");
	if (parseInt(anotherTimeArray[0]) >= 17) {
		duration.max = 2;
	}
}
/*****************************************************************************************************************************
	Display End Time in CreateEvent.html and EditingEvent.html
*****************************************************************************************************************************/
function displayEndTime() {
	var startTime = document.getElementById("startTime").value;
	var duration = document.getElementById("duration").value;
	var anotherTimeArray = startTime.split(":");
	var endTimeHoursCalculated = parseInt(anotherTimeArray[0]) + parseInt(duration);
	anotherTimeArray[0] = endTimeHoursCalculated;
	var endTimeString = anotherTimeArray.join(":");
	document.getElementById("endTime").innerHTML = endTimeString;
}
/*****************************************************************************************************************************
	Validate information entered by user first.
	If validation 'passed', move on to create event and redirect them to ListOfEvents.html.
	Otherwise, prompt the user to enter correct input and break out of function.
*****************************************************************************************************************************/
function cEvent() {
	var endorsed = null;
	var eventsList = JSON.parse(localStorage["eventsList"]);
	var userInformation = JSON.parse(localStorage["userInformation"]);
    var eventsObject;
	var trueOrFalse;
	var currentUser = localStorage["currentUser"];
	var adminDetails = localStorage.getItem("Superuser");
	var usersIndex;
	if (adminDetails != null) {
		adminDetails = JSON.parse(localStorage["Superuser"]);
	}
	if ((typeof (JSON.parse(currentUser))) == "string") {
		currentUser = currentUser;
	} else {
		usersIndex = JSON.parse(localStorage["currentUser"]);
	}
	var username;
	var accType;
	if (usersIndex != null) {
		username = userInformation[usersIndex].username;
		accType = userInformation[usersIndex].accountType;
	} else {
		username = adminDetails.username;
		accType = adminDetails.accountType;
	}
	// Start of selecting values
	var nameOfEvent = document.getElementById("nameOfEvent").value;
	var date = document.getElementById("date").value;
	var startTime = document.getElementById("startTime").value;
	var duration = document.getElementById("duration").value;
	var endTime = document.getElementById("endTime").innerHTML;
	var audienceSize = document.getElementById("audienceSize").value;
	var locationSuggested = document.getElementById("location").innerHTML;
	var String1 = "Location: Sports Hall";
	var String2 = "Location: LTL-1";
	var String3 = "Location: Tutorial Room";
	var String4 = "Location: Sports Stadium";
	var String5 = "Location: Swimming Pool";
	if (locationSuggested != String1 && locationSuggested != String2 && locationSuggested != String3 && locationSuggested != String4 && locationSuggested != String5) {
		alert("Please choose a location for your event.");
		trueOrFalse = false;
		return trueOrFalse;
	}
	var locationInput = document.getElementById("location").innerHTML;
	var locationSelected = locationInput.substring(10);
	console.log(locationSelected);
	var descriptionOfEvent = document.getElementById("inputEvent").value;
	// End of selecting values
	var todaysDate = new Date();
	var todaysDateString = todaysDate.toDateString();
	var Date1 = Date.parse(date);
	var Date2 = new Date(Date1);
	var Date3 = Date2.toDateString();
	var Day1 = Date2.getDay();
	var timeNow = todaysDate.getHours();
	var timeArray = startTime.split(":");
	if (accType === "Educator" || accType === "Admin") {
		endorsed = true;
	}
	// Start of validation
	if (nameOfEvent == "") {
		alert("Please fill up the name of your event.");
		trueOrFalse = false;
		return trueOrFalse;
	} else if (date == "") {
		alert("Please fill up the date of the event.");
		trueOrFalse = false;
		return trueOrFalse;
	} else if (Day1 === 0) {
		alert("No one is permitted to create events on Sundays.");
		trueOrFalse = false;
		return trueOrFalse;
	} else if (todaysDateString === Date3 && timeNow > parseInt(timeArray[0], 10)) {
		alert("Please enter a reasonable time.");
		trueOrFalse = false;
		return trueOrFalse;
	} else if (todaysDate > Date2 && (todaysDateString === Date3) == false) {
		alert("Please enter a reasonable date.");
		trueOrFalse = false;
		return trueOrFalse;
	} else if (startTime == "") {
		alert("Please fill up the time of the event.");
		trueOrFalse = false;
		return trueOrFalse;
	} else if (parseInt(timeArray[0], 10) < 9 || parseInt(timeArray[0], 10) > 19) {
		alert("You are only allowed to schedule an event between 9am and 7pm. Please enter a valid time.");
		trueOrFalse = false;
		return trueOrFalse;
	} else if (duration == "") {
		alert("Please fill up the duration of the event.");
		trueOrFalse = false;
		return trueOrFalse;
	} else if (parseInt(duration, 10) > 10) {
		alert("You are only allowed to create an event that is max 10 hours long.");
		trueOrFalse = false;
		return trueOrFalse;
	} else if (descriptionOfEvent == "") {
		alert("Please fill up the description of the event.");
		trueOrFalse = false;
		return trueOrFalse;
		// End of validation
	} else {
		// Start of function
		if (!checkExistingEventDetails(date, startTime)) {
			eventsObject = {
				"username": username,
				"accType": accType,
				"nameOfEvent": nameOfEvent,
				"date": date,
				"startTime": startTime,
				"duration": duration,
				"endTime": endTime,
				"audienceSize": audienceSize,
				"locat": locationSelected,
				"description": descriptionOfEvent,
				"endorsed": endorsed,
				"active": "active"
			};
			eventsList.push(eventsObject);
			localStorage.setItem("eventsList", JSON.stringify(eventsList));
			window.location.href = "ListOfEvents.html";
		// End of function
		}
	}
}
/*****************************************************************************************************************************
	Validate information entered by user first first.
	If validation 'passed', move on to edit event and redirect them to ListOfEvents.html.
	Otherwise, prompt the user to enter correct input and break out of function.
*****************************************************************************************************************************/
function editEvent() {
	var endorsed = null;
	var usersAns = confirm("Are you sure you want to edit this event? This process is not reversible.");
	if (usersAns == true) {
		var trueOrFalse;
		var userInformation = JSON.parse(localStorage["userInformation"]);
		var eventsList = JSON.parse(localStorage["eventsList"]);
		var specialNum = JSON.parse(localStorage["specialIndex"]);
		var currentUser = localStorage["currentUser"];
		var adminDetails = localStorage.getItem("Superuser");
		var usersIndex;
		if (adminDetails != null) {
			adminDetails = JSON.parse(localStorage["Superuser"]);
		}
		if ((typeof (JSON.parse(currentUser))) == "string") {
			currentUser = currentUser;
		} else {
			usersIndex = JSON.parse(localStorage["currentUser"]);
		}
		var username;
		var accType;
		if (usersIndex != null) {
			username = userInformation[usersIndex].username;
			accType = userInformation[usersIndex].accountType;
		} else {
			username = adminDetails.username;
			accType = adminDetails.accountType;
		}
		if (accType === "Educator" || accType === "Admin") {
			endorsed = true;
		}
		// Start of selecting values
		var nameOfEvent = document.getElementById("nameOfEvent").value;
		var date = document.getElementById("date").value;
		var startTime = document.getElementById("startTime").value;
		var duration = document.getElementById("duration").value;
		var endTime = document.getElementById("endTime").innerHTML;
		var audienceSize = document.getElementById("audienceSize").value;
		var locationSuggested = document.getElementById("location").innerHTML;
		var String1 = "Location: Sports Hall";
		var String2 = "Location: LTL-1";
		var String3 = "Location: Tutorial Room";
		var String4 = "Location: Sports Stadium";
		var String5 = "Location: Swimming Pool";
		if (locationSuggested != String1 && locationSuggested != String2 && locationSuggested != String3 && locationSuggested != String4 && locationSuggested != String5) {
			alert("Please choose a location for your event.");
			trueOrFalse = false;
			return trueOrFalse;
		}
		var locationInput = document.getElementById("location").innerHTML;
		var locationSelected = locationInput.substring(10);
		var descriptionOfEvent = document.getElementById("inputEvent").value;
		// End of selecting values
		var todaysDate = new Date();
		var todaysDateString = todaysDate.toDateString();
		var Date1 = Date.parse(date);
		var Date2 = new Date(Date1);
		var Date3 = Date2.toDateString();
		var Day1 = Date2.getDay();
		var timeNow = todaysDate.getHours();
		var timeArray = startTime.split(":");
		// Start of validation
		if (nameOfEvent == "") {
			alert("Please fill up the name of your event.");
			trueOrFalse = false;
			return trueOrFalse;
		} else if (date == "") {
			alert("Please fill up the date of the event.");
			trueOrFalse = false;
			return trueOrFalse;
		} else if (Day1 === 0) {
			alert("No one is permitted to create events on Sundays.");
			trueOrFalse = false;
			return trueOrFalse;
		} else if (todaysDateString === Date3 && timeNow > parseInt(timeArray[0], 10)) {
			alert("Please enter a reasonable time.");
			trueOrFalse = false;
			return trueOrFalse;
		} else if (todaysDate > Date2 && (todaysDateString === Date3) == false) {
			alert("Please enter a reasonable date.");
			trueOrFalse = false;
			return trueOrFalse;
		} else if (startTime == "") {
			alert("Please fill up the time of the event.");
			trueOrFalse = false;
			return trueOrFalse;
		} else if (parseInt(timeArray[0], 10) < 9 || parseInt(timeArray[0], 10) > 19) {
			alert("You are only allowed to schedule an event between 9am and 7pm. Please enter a valid time.");
			trueOrFalse = false;
			return trueOrFalse;
		} else if (duration == "") {
			alert("Please fill up the duration of the event.");
			trueOrFalse = false;
			return trueOrFalse;
		} else if (parseInt(duration, 10) > 10) {
			alert("You are only allowed to create an event that is max 10 hours long.");
			trueOrFalse = false;
			return trueOrFalse;
		} else if (audienceSize == "") {
			alert("Please fill up the audience size you expect for the event.");
			trueOrFalse = false;
			return trueOrFalse;
		} else if (descriptionOfEvent == "") {
			alert("Please fill up the description of the event.");
			trueOrFalse = false;
			return trueOrFalse;
			// End of validation
		} else {
			var objForInspection = {
				nameOfEvent: nameOfEvent,
				date: date,
				startTime: startTime,
				duration: duration,
				locat: locationSelected,
				audienceSize: audienceSize,
				descriptionOfEvent: descriptionOfEvent
			};
			if (madeChanges(objForInspection) === true) {
				window.location.href = "ListOfEvents.html";
				trueOrFalse = false;
				return trueOrFalse;
			}
			// Start of function
			var eventsObject = {
				"username": username,
				"accType": accType,
				"nameOfEvent": nameOfEvent,
				"date": date,
				"startTime": startTime,
				"duration": duration,
				"endTime": endTime,
				"audienceSize": audienceSize,
				"locat": locationSelected,
				"description": descriptionOfEvent,
				"endorsed": endorsed,
				"active": "active"
			};
			eventsList[specialNum] = eventsObject;
			localStorage["eventsList"] = JSON.stringify(eventsList);
			window.location.href = "ListOfEvents.html";
			// End of function
		}
	}
}
/*****************************************************************************************************************************
	
*****************************************************************************************************************************/
function madeChanges(obj) {
	var eventsList = JSON.parse(localStorage["eventsList"]);
	var specialNum = JSON.parse(localStorage["specialIndex"]);
	var nameOfEvent1 = eventsList[specialNum].nameOfEvent;
	var date1 = eventsList[specialNum].date;
	var startTime1 = eventsList[specialNum].startTime;
	var duration1 = eventsList[specialNum].duration;
	var audienceSize1 = eventsList[specialNum].audienceSize;
	var location1 = eventsList[specialNum].locat;
	var descriptionOfEvent1 = eventsList[specialNum].description;
	var nameOfEvent2 = obj.nameOfEvent;
	var date2 = obj.date;
	var startTime2 = obj.startTime;
	var duration2 = obj.duration;
	var location2 = obj.locat;
	var audienceSize2 = obj.audienceSize;
	var descriptionOfEvent2 = obj.descriptionOfEvent;
	if ((nameOfEvent1 === nameOfEvent2) && (date1 === date2) && (startTime1 === startTime2) && (duration1 === duration2) && (audienceSize1 === audienceSize2) && (location1 === location2) && (descriptionOfEvent1 === descriptionOfEvent2)) {
		var usersConfirmation = confirm("You have not edited anything. Continue?");
	}
	return usersConfirmation;
	console.log(userConfirmation);
}
/*****************************************************************************************************************************
	Check whether there are any other events scheduled on the same day at the same time.
	If yes, alert the user and ask them to enter again.
	Otherwise, let them continue.
*****************************************************************************************************************************/
function checkExistingEventDetails(date, startTime) {
	var existing = false;
	var eventsList = JSON.parse(localStorage["eventsList"]);
	for (var i = 0; i < eventsList.length; i++){
		var eventsObject = eventsList[i];
		if (eventsObject.date == date && eventsObject.startTime == startTime && eventsObject.locat == locationSelected){
			existing = true;
			break;
		} else {
			for (var j = 0; j < eventsList.length; j++) {
				if (eventsObject.date == date && parseInt(eventsObject.startTime.split(":")[0]) < parseInt(eventsList[j].endTime.split(":")[0]) && eventsObject.locat == locationSelected) {
					existing = true;
					break;
				}
			}
		}
	}
	if (existing) {
		alert("There is already another event scheduled on that day at the specified time at the same location. Please select another date, time and/or location");
	}
	return existing;
} // Check whther same location && same timing
/*****************************************************************************************************************************
	Display Events in ListOfEvents.html
	To do that, retrieve details from localStorage on load.
*****************************************************************************************************************************/
function loadObjectFromStorage() {
	userInformation = JSON.parse(localStorage["userInformation"]);
	var eventsList = localStorage.getItem("eventsList");
	var currentUser = localStorage["currentUser"];
	var adminDetails = localStorage.getItem("Superuser");
	var usersIndex;
	if (adminDetails != null) {
		adminDetails = JSON.parse(localStorage["Superuser"]);
	}
	if ((typeof (JSON.parse(currentUser))) == "string") {
		currentUser = currentUser;
	} else {
		usersIndex = JSON.parse(localStorage["currentUser"]);
	}
	var username;
	var accType;
	if (usersIndex != null) {
		username = userInformation[usersIndex].username;
		accType = userInformation[usersIndex].accountType;
	} else if (JSON.parse(currentUser) === "Admin") {
		username = adminDetails.username;
		accType = adminDetails.accountType;
	} else {
		username = null;
		accType = null;
	}
	automaticDelete();
	if (eventsList != null) {
		eventsList = JSON.parse(eventsList);
		for (var i = eventsList.length - 1; i >= 0; i--) {
			divNum = i;
			var div = document.createElement("div");
			div.id = "newEvent" + divNum;
			div.className = "newEvents";
			div.innerHTML = "<p>The details of your events are as follows are as follows:" + 
							"<br/>Name of host:<br/>" +
								"<strong>" + eventsList[i].username + "</strong>" + 
							"<br/>Profile:<br/>" +
								"<strong>" + eventsList[i].accType + "</strong>" + 
							"<br/>Name of Event:<br/>" + 
								"<strong>" + eventsList[i].nameOfEvent + "</strong>" + 
							"<br/>Date:<br/>" + 
								"<strong>" + eventsList[i].date + "</strong>" + 
							"<br/>Start Time:<br/>" + 
								"<strong>" + eventsList[i].startTime + " - " + eventsList[i].endTime + "</strong>" + 
							"<br/>Duration:<br/>" + 
								"<strong>" + eventsList[i].duration + " hrs" + "</strong>" + 
							"<br/>Location:<br/>" + 
								"<strong>" + eventsList[i].locat + "</strong>" + 
							"<br/>Audience Size:<br/>" + 
								"<strong>" + eventsList[i].audienceSize + "</strong>" + 
							"<br/>Description of Event:<br/>" + 
								"<strong>" + eventsList[i].description + "</strong></p>";
			var delBtn = "<input type='button' value='Delete Event' style='padding:10px;' onclick='dEvent(this.parentNode)'/>";
			var editBtn = "<input type='button' value='Edit Event' style='padding:10px;' onclick='sendInfoToEditEvent(this.parentNode)'/>";
			var endorseBtn = "<input type='button' value='Endorse Event' style='padding:10px;' onclick='endorseEvent(this.parentNode)'/>";
			if (username != null && accType != null) {
				if ((accType === "Educator" || accType === "Admin") && (username != eventsList[i].username) && (eventsList[i].accType != "Admin")) {
					div.innerHTML += "<br/>" + delBtn + "&nbsp;&nbsp;&nbsp;" + endorseBtn;
				} else if ((accType === "Admin") && (username === eventsList[i].username)) {
					div.innerHTML += "<br/>" + editBtn + "&nbsp;&nbsp;&nbsp;" + delBtn;
				} else if (eventsList[i].accType === "Student" && username === eventsList[i].username) {
					div.innerHTML += "<br/>" + editBtn + "&nbsp;&nbsp;&nbsp;" + delBtn;
				} else if ((eventsList[i].accType === "Educator" || eventsList[i].accType === "Admin") && (username === eventsList[i].username)) {
					div.innerHTML += "<br/>" + editBtn + "&nbsp;&nbsp;&nbsp;" + delBtn;
				}
			}
			if (div.id == "newEvent0") {
				div.style.marginBottom = "85px";
			}
			if (eventsList[i].endorsed == true) {
				// div.style.backgroundColor = "rgba(255, 169, 0, 0.8)";
				div.style.backgroundColor = "#ffa900";
			}
			if (eventsList[i].active == "deleted") {
				var reasonsList = JSON.parse(localStorage["reasonsList"]);
				for (var j = 0; j < reasonsList.length; j++) {
					if (reasonsList[j].nameOfEvent == eventsList[i].nameOfEvent) {
						div.innerHTML = "Name Of Event: <br/><strong>" + reasonsList[j].nameOfEvent + 
										"</strong><br/>This event was deleted because of the following reason: <br/>" + 
										"<strong>" + reasonsList[j].reasonForDeletion + "</strong>";
						div.style.backgroundColor = "rgba(0, 0, 0, 0.3)";
						div.style.color = "white";
					}
				}
			}
			var mainDiv = document.getElementById("container");
			mainDiv.appendChild(div);
		}
	}
}
/*****************************************************************************************************************************
	Delete an event automatically if it is already over (outdated).
*****************************************************************************************************************************/
function automaticDelete() {
	var eventsList = localStorage.getItem("eventsList");
	if (eventsList === null) {
		return false;
	}
	eventsList = JSON.parse(eventsList);
	if (eventsList != null) {
		var todaysDate = new Date();
		var todaysDateString = todaysDate.toDateString();
		var timeNow = todaysDate.getHours();
		for (var i = 0; i < eventsList.length; i++) {
			var Date1 = Date.parse(eventsList[i].date);
			var Date2 = new Date(Date1);
			var Date3 = Date2.toDateString();
			var timeArray = eventsList[i].endTime.split(":");
			if (todaysDateString === Date3 && timeNow > parseInt(timeArray[0], 10)) {
				eventsList.splice(i, 1);
			} else if (todaysDate > Date2 && (todaysDateString === Date3) == false) {
				eventsList.splice(i, 1);
			}
		}
		localStorage["eventsList"] = JSON.stringify(eventsList);
	}
}
/*****************************************************************************************************************************
	Display details of events entered by user on EditingEvent.html
	To do that, retrieve details from localStorage on load.
	Details include index of object and event details found inside the particular object.
*****************************************************************************************************************************/
function retrieveObjectFromStorage() {
	userInformation = JSON.parse(localStorage["userInformation"]);
	eventsList = JSON.parse(localStorage["eventsList"]);
	var specialNum = JSON.parse(localStorage["specialIndex"]);
	document.getElementById("nameOfEvent").value = eventsList[specialNum].nameOfEvent;
	document.getElementById("date").value = eventsList[specialNum].date;
	document.getElementById("startTime").value = eventsList[specialNum].startTime;
	document.getElementById("duration").value = eventsList[specialNum].duration;
	document.getElementById("endTime").innerHTML = eventsList[specialNum].endTime;
	document.getElementById("audienceSize").value = eventsList[specialNum].audienceSize;
	document.getElementById("inputEvent").value = eventsList[specialNum].description;
}
/*****************************************************************************************************************************
	ListOfEvents.html to 'send' index to EditingEvent.html
	To do this, save selected index to localStorage for the other page's use.
*****************************************************************************************************************************/
function sendInfoToEditEvent(divOfInterest) {
	var divId = divOfInterest.id;
	var i = divId.charAt(divId.length - 1);
	var trueOrFalse;
	var userInformation = JSON.parse(localStorage["userInformation"]);
	var eventsList = JSON.parse(localStorage["eventsList"]);
	var currentUser = localStorage["currentUser"];
	var adminDetails = localStorage.getItem("Superuser");
	var usersIndex;
	if (adminDetails != null) {
		adminDetails = JSON.parse(localStorage["Superuser"]);
	}
	if ((typeof (JSON.parse(currentUser))) == "string") {
		currentUser = currentUser;
	} else {
		usersIndex = JSON.parse(localStorage["currentUser"]);
	}
	var username;
	var accType;
	if (usersIndex != null) {
		username = userInformation[usersIndex].username;
		accType = userInformation[usersIndex].accountType;
	} else {
		username = adminDetails.username;
		accType = adminDetails.accountType;
	}
	var num = i;
	localStorage["specialIndex"] = JSON.stringify(num);
	window.location.href = "EditingEvent.html";
}
/*****************************************************************************************************************************
	dEvent === delete Event
	Retrieve index and event details from localStorage.
	Once information collected, remove the event detail from array to 'delete' the event.
*****************************************************************************************************************************/
function dEvent(divOfInterest) {
	var divId = divOfInterest.id;
	var i = divId.charAt(divId.length - 1);
	var trueOrFalse;
	var userInformation = JSON.parse(localStorage["userInformation"]);
	var eventsList = JSON.parse(localStorage["eventsList"]);
	var currentUser = localStorage["currentUser"];
	var adminDetails = localStorage.getItem("Superuser");
	var usersIndex;
	if (adminDetails != null) {
		adminDetails = JSON.parse(localStorage["Superuser"]);
	}
	if ((typeof (JSON.parse(currentUser))) == "string") {
		currentUser = currentUser;
	} else {
		usersIndex = JSON.parse(localStorage["currentUser"]);
	}
	var username;
	var accType;
	if (usersIndex != null) {
		username = userInformation[usersIndex].username;
		accType = userInformation[usersIndex].accountType;
	} else {
		username = adminDetails.username;
		accType = adminDetails.accountType;
	}
	var nameOfEvent = eventsList[i].nameOfEvent;
	var name = eventsList[i].username;
	var usersConfirmation = confirm("Are you sure you want to delete the event? This process is not reversible.");
	if (usersConfirmation === true) {
		var reasonForDeletion = prompt("Please specify the reason for deleting this event.", "");
		while (reasonForDeletion == "") {
			reasonForDeletion = prompt("You did not enter any reason. \nPlease specify the reason for deleting this event.", "");
		}
		var deletedObject = {
			"username": name,
			"nameOfEvent": nameOfEvent,
			"reasonForDeletion": reasonForDeletion,
			"index": i,
			"deletedBy": username
		};
		reasonsList = localStorage.getItem("reasonsList");
		if (reasonsList === null) {
			reasonsList = [];
			reasonsList.push(deletedObject);
			localStorage["reasonsList"] = JSON.stringify(reasonsList);
		} else {
			reasonsList = JSON.parse(localStorage["reasonsList"]);
			reasonsList.push(deletedObject);
			localStorage["reasonsList"] = JSON.stringify(reasonsList);
		}
		divOfInterest.style.display = "none";
		username = eventsList[i].username;
		accType = eventsList[i].accType;
		nameOfEvent = eventsList[i].nameOfEvent;
		var date = eventsList[i].date;
		var startTime = eventsList[i].startTime;
		var duration = eventsList[i].duration;
		var endTime = eventsList[i].endTime;
		var audienceSize = eventsList[i].audienceSize;
		var locat = eventsList[i].locat;
		var descriptionOfEvent = eventsList[i].descriptionOfEvent;
		var endorsed = eventsList[i].endorsed;
		var eventsObject = {
			"username": username,
			"accType": accType,
			"nameOfEvent": nameOfEvent,
			"date": date,
			"startTime": startTime,
			"duration": duration,
			"endTime": endTime,
			"audienceSize": audienceSize,
			"locat": locat,
			"description": descriptionOfEvent,
			"endorsed": endorsed,
			"active": "deleted"
		};
		eventsList[i] = eventsObject;
		localStorage["eventsList"] = JSON.stringify(eventsList);
		//eventsList.splice(i, 1);
		//localStorage["eventsList"] = JSON.stringify(eventsList);
		function confirmationOfDelete() {
			alert("Your event has been deleted successfully");
			location.reload();
		}
		setTimeout(confirmationOfDelete, 0500);
	}
}
/*****************************************************************************************************************************
	To endorse events (This functionality is only for lecturers and administrators)
*****************************************************************************************************************************/
function endorseEvent(divOfInterest) {
	var divId = divOfInterest.id;
	var i = divId.charAt(divId.length - 1);
	var eventsList = JSON.parse(localStorage["eventsList"]);
	var usersConfirmation = confirm("Are you sure you want to endorse the event? This process is not reversible.");
	if (usersConfirmation === true) {
		divOfInterest.style.backgroundColor = "#ffa900";
		divOfInterest.style.transition = "background-color 1.0s ease";
		eventsList[i].endorsed = true;
		localStorage["eventsList"] = JSON.stringify(eventsList);
	}
}
function findEvent(username, accType, nameOfEvent, date, duration, audienceSize, locat, endorsed, active) {
    var found = false;
	var eventsObject = null;
	var eventsList = JSON.parse(localStorage["eventsList"]);
	var dateEntered = document.getElementById("date").value;
	var durationEntered = document.getElementById("duration").value;
	for (i = 0; i < eventsList.length; i++){
		eventsObject = eventsList[i];
		if (eventsObject.date == dateEntered || eventsObject.duration == durationEntered) {
			found = true;
			var el = document.getElementById("foundEvent");
			var div = document.createElement("div");
			div.style.color = "white";
			div.style.border = "1px solid white";
			div.style.margin = "30px";
			div.innerHTML = "<p>" + 
							"<br/>Name of host:<br/>" +
								"<strong>" + eventsObject.username + "</strong>" + 
							"<br/>Profile:<br/>" +
								"<strong>" + eventsObject.accType + "</strong>" + 
							"<br/>Name of Event:<br/>" + 
								"<strong>" + eventsObject.nameOfEvent + "</strong>" + 
							"<br/>Date:<br/>" + 
								"<strong>" + eventsObject.date + "</strong>" + 
							"<br/>Start Time:<br/>" + 
								"<strong>" + eventsObject.startTime + " - " + eventsObject.endTime + "</strong>" + 
							"<br/>Duration:<br/>" + 
								"<strong>" + eventsObject.duration + " hrs" + "</strong>" + 
							"<br/>Location:<br/>" + 
								"<strong>" + eventsObject.locat + "</strong>" + 
							"<br/>Audience Size:<br/>" + 
								"<strong>" + eventsObject.audienceSize + "</strong>" + 
							"<br/>Description of Event:<br/>" + 
								"<strong>" + eventsObject.description + "</strong></p>";
			el.appendChild(div);
			break;
		}
	}
	if (!found) {
		document.getElementById("foundEvent").innerHTML = "No events found!!";
	}
	return;
}