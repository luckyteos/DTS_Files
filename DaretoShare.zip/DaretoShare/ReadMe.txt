/*Home Page*/
1) Mailing List --> Click the undelined "Join" in the sentence just above the footer.

2) FAQ --> In the orange div, click the learn more button.


/*Blog Page*/
1) To create new Entry, you need to login. An alert message will pop out and you will be send to the login page.

2) As a guest, you are only able to view the blog post, the comments and flag the comments. To be able to create, edit, and delete both posts and comments, you will need to login.

3) Both students and educators will be given the same privilege, which is to create posts and comments, edit and delete posts and comments created by them. 

4) ONLY administrators are allowed to create, edit, and delete all posts and comments.

5) Everyone is not allowed to post the same comments more than 3 times in a row.


/*Events Page*/
1) To add, edit, delete the user must login.

2) As a guest, the user can only view the various events available.

3) Educators and administrators are allowed to both endorse and delete students' events available.

4) Everyone with an account can create, edit, or delete their OWN events.

5) Everyone is allowed to create a maximum of 5 events at any one point in time so as to minimise the stress generated over organising the events.

6) Both the create and edit event pages require all details to be filled up before submitting.

7) The audience size needs to be filled before selecting the location.


/*Profile Page*/
1) Under account settings, advanced settings is only allowed for administrators.


/*Videos Page*/
1) As a guest, the user will only be able to view the videos and comments.

2) Educators and administrator are allowed to delete students' comments.

3) Everyone is allowed to create, edit, delete their OWN comments.