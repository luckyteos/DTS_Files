function openNav() {
	document.getElementById("sideNav").style.width = "100%";
	document.getElementById("sideNav").style.transition = "width 0.6s ease";
} function closeNav() {
	document.getElementById("sideNav").style.width = "0";
	document.getElementById("sideNav").style.transition = "width 0.6s ease";
}
function visible() {
	var invisibleEls = document.querySelectorAll("#sideNav #divCloak .invisible");
	for (var i in invisibleEls) {
		invisibleEls[i].style.display = "block";
	}
} function invibilityCloak() {
	var invisibleEls = document.querySelectorAll("#sideNav #divCloak .invisible");
	for (var i in invisibleEls) {
		invisibleEls[i].style.display = "none";
	}
}