var currentUser;
var userInformation;
var username;
var Superuser;

function setUp(){
	currentUser = localStorage.getItem("currentUser");
	if(currentUser == null){
		currentUser = [];
	}
	else{
		currentUser = JSON.parse(currentUser);
	}
	userInformation = localStorage.getItem("userInformation");
	if(userInformation == null){
		userInformation = [];
	}
	else{
		userInformation = JSON.parse(userInformation);
	}
	Superuser = localStorage.getItem("Superuser");
	if(Superuser == null){
		Superuser = [];
	}
	else{
		Superuser = JSON.parse(Superuser);
	}
}	
function adminAccess(){
	var currentUser = JSON.parse(localStorage["currentUser"]);
	if(currentUser !== "Admin"){
		alert("You must be an administrator to view this content!");
		return false;
	}
	else{
		document.getElementById("users").style.display = "inline";
		document.getElementById("close").style.display = "inline";
		document.getElementById("delete").style.display = "inline";
	}	
}
function closeTable(){
	document.getElementById("users").style.display = "none";
	document.getElementById("close").style.display = "none";
	document.getElementById("delete").style.display = "none";
}
function logout(){
	var value = JSON.parse(localStorage["currentUser"]);
	value = null;
	localStorage.setItem("currentUser", JSON.stringify(value));
	localStorage.removeItem("Superuser");
	window.location.href = "../../Home.html";
}
function deleteAccount(){
	var index = JSON.parse(localStorage["currentUser"]);
	var userInformation = JSON.parse(localStorage["userInformation"]);
		var obj = userInformation;
			obj.splice(index, 1);
			localStorage.setItem("userInformation", JSON.stringify(obj));
			var index = null;
			localStorage.setItem("currentUser", JSON.stringify(index));
			window.location.href= "../../Home.html";
}
function updateContact(){
	var Usertype = JSON.parse(localStorage["currentUser"]);
	if(Usertype === "Admin"){
		alert("You cannot change any contact number!");
		return false;
	}
	else{
		var user = JSON.parse(localStorage["currentUser"]);
		var userInformation = JSON.parse(localStorage["userInformation"]);
		var telValidate = /[6|8|9][0-9]{7}/;
		var newContact = prompt("Enter your new Contact Number:");
		if(newContact == ""){
			alert("Unable to update. No contact number input.");
			return false;
		}
		else if(!telValidate.test(newContact) || newContact.length > 8){
			alert("Contact number must start with 6, 8 or 9 and be 8 digits long.");
			return false;
		}
		else{
		userInformation[user].contact = newContact;
		localStorage.setItem("userInformation", JSON.stringify(userInformation));
		location.reload();
		}
	}
}
function updateEmail(){
	var Usertype = JSON.parse(localStorage["currentUser"]);
	if(Usertype === "Admin"){
		alert("You cannot change any email address!");
		return false;
	}
	else{
		var target = JSON.parse(localStorage["currentUser"]);
		var userInformation = JSON.parse(localStorage["userInformation"]);
		var emailValidate = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
		var newEmail = prompt("Enter your new Email address:");
		if(newEmail == ""){
			alert("Unable to update. No email address input.");
			return false;
		}
		else if(!emailValidate.test(newEmail)){
			alert("Email is invalid!");
			return false;
		}
		else{	
		userInformation[target].email = newEmail;
		localStorage.setItem("userInformation", JSON.stringify(userInformation));
		location.reload();
		}
	}
}
function deleteUser(){
	var userName = prompt("Enter the username of the account you want to delete:");
	var userInformation = JSON.parse(localStorage["userInformation"]);
	for(i = 0; i < userInformation.length; i++){
		var obj = userInformation[i];
		if(obj.username == userName){
			userInformation.splice(i, 1);
			localStorage.setItem("userInformation", JSON.stringify(userInformation));
			location.reload();
		}
	}
}