

var feedbackValue;
var feedbackStore;
var userInformation;
var superUser;
var currentUser;

document.addEventListener("DOMContentLoaded", docIsReady);

function docIsReady () {
	
	feedbackStore = localStorage.getItem("feedbackInfo");
	userInformation = localStorage.getItem ("userInformation");
	superUser = localStorage.getItem("Superuser");
	currentUser = localStorage.getItem ("currentUser");
	feedbackValue = localStorage.getItem ("feedbackIndex");
	
	if (feedbackStore == null) {
		feedbackStore = [];		
	}
	else {
		feedbackStore = JSON.parse(feedbackStore);
	}
	
	if (userInformation == null) {
		userInformation = [];
	}
	else {
		userInformation = JSON.parse (userInformation);
	}
	
	if (superUser == null) {
		superUser = [];
	}
	else {
		superUser = JSON.parse (superUser);
	}
	
	if (currentUser === "null") {
		currentUser = [];
	}
	else {
		currentUser = JSON.parse (currentUser);
	}
	
	if (feedbackValue == null) {
		feedbackValue = [];
	}
	else {
		feedbackValue = JSON.parse(feedbackValue);
	}
		
}

function submitFeedback () {
	// Getting Form Elements
	var nameField = document.forms ["feedback"]["name"];
	var emailField = document.forms ["feedback"]["emailfield"];
	var categoryField = document.forms ["feedback"]["feedbackCat"];
	var feedbackField = document.forms ["feedback"]["feedbackBox"];
	var subjectField = document.forms ["feedback"]["eventDes"];
	
	// Getting Form elements values
	var name = nameField.value;
	var email = emailField.value;
	var category = categoryField.value;
	var feedback = feedbackField.value;
	var subject = subjectField.value;
	var categorySelected = categoryField.selectedIndex;
	
	var indexPresent = localStorage.getItem ("feedbackIndex");
	
	var userMessage = document.getElementById("Info");
	
	if (indexPresent == null) { // If Statement to check for "update value"
		
		if (currentUser.length === 0) { // If Statement to check if there is a user logged in
	
			if (name == "" && email == "" && subject == "" && feedback == "") {
				alert ("Please fill in the feedback form :)");	
			}	
			else {
				if (nameCheck (nameField) && emailCheck(email) && categoryValidation(categorySelected) && subjectValidation (subject) && feedbackValidation (feedback)){
					userMessage.style.display = "none";
					if (!sameFeedback ()) {
					obj = {"name": name, "username": "guest", "accountType": "Guest", "email" : email , "category": category, "subjectName": subject , "feedback" : feedback};
					feedbackStore.push(obj);
					localStorage.setItem ("feedbackInfo",JSON.stringify (feedbackStore));
					window.location.href = "feedback_success.html";
					}
					else {
						alert ("Same Feedback exists");
						window.location.href = "feedback.html";
					}
				}
				
			}
		
		}
		
		else { // If user is logged in - execute this code
		
			var userLogin = currentUser;
			var userName = userInformation[userLogin].username;
			var accountType = userInformation[userLogin].accountType;
			
			if (name == "" && email == "" && subject == "" && feedback == "") {
				alert ("Please fill in the feedback form :)");	
			}	
			else {
				if (nameCheck (nameField) && emailCheck(email) && categoryValidation(categorySelected) && subjectValidation (subject) && feedbackValidation (feedback)){
					userMessage.style.display = "none";
					if (!sameFeedback ()) {
					obj = {"name": name, "username": userName, "accountType": accountType, "email" : email , "category": category, "subjectName": subject , "feedback" : feedback};
					feedbackStore.push(obj);
					localStorage.setItem ("feedbackInfo",JSON.stringify (feedbackStore));
					window.location.href = "feedback_success.html";
					}
					else {
						alert ("Same Feedback exists");
						window.location.href = "feedback.html";
					}
				}
				
			}
			
		}
		
		indexPresent = [];
	}
	else { // If User plans to update feedback - update feedback section of code
		indexPresent = JSON.parse (indexPresent);
		var indexNo = indexPresent[0].indexValue;
		
		if (currentUser.length === 0) { // If Guest is logged in and wants to update feedback
		
			var deleteyorN = confirm ("Are you Sure you want to update your feedback?");
		
			if (deleteyorN) {
			
				if (name == "" && email == "" && subject == "" && feedback == "") {
					alert ("Please fill in the feedback form :)");	
				}	
				else {
					if (nameCheck (nameField) && emailCheck(email) && categoryValidation(categorySelected) && subjectValidation (subject) && feedbackValidation (feedback)){
						userMessage.style.display = "none";
						if (!sameFeedback ()) {
						obj = {"name": name, "username": "guest", "accountType": "Guest", "email" : email , "category": category, "subjectName": subject , "feedback" : feedback};
						feedbackStore.splice (indexNo,1,obj);
						localStorage.setItem ("feedbackInfo",JSON.stringify (feedbackStore));
						localStorage.removeItem ("feedbackIndex");
						window.location.href = "feedback_success.html";
						}
						else {
							alert ("Same Feedback exists");
							window.location.href = "feedback.html";
						}
					}
					
				}
			
			}
			else {
				alert ("No Changes Have been Made \nRedirecting you back to where you came from");
				window.location.href = "feedback_review.html";
				return false;
			}
		
		}
		else { // If Logined User wants to update feedback
			
			var deleteyorN = confirm ("Are you Sure you want to update your feedback?");
			var userLogin = currentUser;
			var userName = userInformation[userLogin].username;
			var accountType = userInformation[userLogin].accountType;
		
			if (deleteyorN) {
			
				if (name == "" && email == "" && subject == "" && feedback == "") {
					alert ("Please fill in the feedback form :)");	
				}	
				else {
					if (nameCheck (nameField) && emailCheck(email) && categoryValidation(categorySelected) && subjectValidation (subject) && feedbackValidation (feedback)){
						userMessage.style.display = "none";
						if (!sameFeedback ()) {
						obj = {"name": name, "username": userName, "accountType": accountType, "email" : email , "category": category, "subjectName": subject , "feedback" : feedback};
						feedbackStore.splice (indexNo,1,obj);
						localStorage.setItem ("feedbackInfo",JSON.stringify (feedbackStore));
						localStorage.removeItem ("feedbackIndex");
						window.location.href = "feedback_success.html";
						}
						else {
							alert ("Same Feedback exists");
							window.location.href = "feedback.html";
						}
					}
					
				}
			
			}
			else {
				alert ("No Changes Have been Made \nRedirecting you back to where you came from");
				window.location.href = "feedback_review.html";
				return false;
			}
				
		}
	}
	
	
	
}

function emailCheck (email) {
	
	var emailField = document.forms ["feedback"]["emailfield"];
	var userMessage = document.getElementById("Info");
	
	
	var emailFormat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	
	if (email.match (emailFormat)){
		return true
	}
	else {
		userMessage.style.display = "inline";
		userMessage.innerHTML = "Email Entered is Invalid";
		emailField.focus();
		return false;
	}
	
}

function nameCheck (userInput) {
	
	var nameFormat = /^[A-Za-z\s]+$/;
	var userMessage = document.getElementById("Info");
	
	if (userInput.value.length <= 30 && userInput.value.length >= 3) {
		if (userInput.value.match (nameFormat)) {
			return true;
		}
		else {
			alert ("Name Entered is invalid");
			return false;
		}
	}	
	else {
		userMessage.style.display = "inline";
		userMessage.innerHTML = "Name Entered is too short or long";
		userInput.focus();
		return false;
	}
	
	
		
}



function feedbackValidation (feedback) {
	
	var userMessage = document.getElementById("Info");
	
	if (feedback == "" || feedback == null) {
		userMessage.style.display = "inline";
		userMessage.innerHTML = "Feedback Field is empty";
		return false;
	}
	return true;
	
	/*if (feedback.length > 4000){
		alert ("Feedback exceeds 4000 characters");
		return false;
	}
	
	return true;
	if (feedback.match(feedbackFormat)) {
		return true;
	}
	else {
		alert ("Please Enter Valid Feedback");
		return false;
	}*/
}

function subjectValidation (subject) {
	
	var userMessage = document.getElementById("Info");
	
	if (subject.length < 5) {
		userMessage.style.display = "inline";
		userMessage.innerHTML = "Subject is too short";
		return false;
	}
	
	return true;
	
}

function categoryValidation (category) {
	
	var userMessage = document.getElementById("Info");
	
	if (category === 0){
		userMessage.style.display = "inline";
		userMessage.innerHTML = "Please Select a feedback category";
		return false;
	}
	return true;
}

function gobackHome () {
	window.location.href = "../../Home.html";
}

function backtoFeedback () {
	window.location.href = "feedback.html";
}

function reviewFeedback () {
	window.location.href = "feedback_review.html";
}

function sameFeedback () {
	
	// Getting Form Elements
	var nameField = document.forms ["feedback"]["name"];
	var emailField = document.forms ["feedback"]["emailfield"];
	var categoryField = document.forms ["feedback"]["feedbackCat"];
	var feedbackField = document.forms ["feedback"]["feedbackBox"];
	var subjectField = document.forms ["feedback"]["eventDes"];
	
	// Getting Form elements values
	var name = nameField.value;
	var email = emailField.value;
	var category = categoryField.value;
	var feedbackInput = feedbackField.value;
	var subject = subjectField.value;
	
	for (var i = 0; i < feedbackStore.length; i++) {
		var feedback = feedbackStore [i];
		if (name == feedback.name) {
			if (email == feedback.email) {
				if (category == feedback.category) {
					if (subject == feedback.subjectName){
						if (feedbackInput == feedback.feedback){
							return true;
							break;
						}
					}
				}
			}
		}
	}
	return false;
}

function feedbackDisplay () {
	
	if (currentUser !== "Admin") { // If User is not an adminstrator
	
		if (currentUser.length !== 0) { // If User Is logged in
		
			for (var i = 0; i < feedbackStore.length; i++) {
				var found = false;
				var currentIndex = currentUser;
				
				if (feedbackStore[i].username === userInformation[currentIndex].username) { // Checking to See if Logged in user has submitted any feedback, then displaying it
				
				found = true;
				
				// Element Creation
				var divCreated = document.createElement ("DIV");
				
				// Attribute set and class set
				divCreated.setAttribute ("id", "className");
				divCreated.id = "feedback"+i;
				divCreated.className = "fbContainer";
				
				// Content Creation
				divCreated.innerHTML = "<p style = 'font-size: 1.2em' >By: "
											+"</br><strong>" + feedbackStore [i].name +"</strong>"
										+"<br/> Subject: "
											+"</br><strong>" +feedbackStore [i].subjectName +"</strong>"
										+"<br/> Category: "
											+"</br><strong>" +feedbackStore [i].category +"</strong></p><br/>"
										+"<input type = 'button' value = 'Update Feedback' style = 'padding:10px' onclick = 'indexStore (this.parentNode)'/>"
										+"&nbsp;&nbsp;&nbsp"
										+"<input type = 'button' value = 'Delete Feedback' style = 'padding:10px' onclick = 'deleteFeedback (this.parentNode)'/>";
				
				//appendChild
				var yes = document.getElementById ("review");
				yes.appendChild (divCreated);
				
				}
			}
			
			
			if (feedbackStore.length == 0) {
				alert ("No Feedback is present");
			}
			
		}
		else { // If User is Not Logged in - Guest User
			var reviewField = document.getElementById("review");
			var email = document.getElementById("emailCheck");
			var checkButton = document.getElementById("emailSubmit");
			email.style.display = "inline";
			checkButton.style.display = "inline";
		}
		
	}
	else if (currentUser === "Admin") { // If user is an administrator
	
		var title = document.getElementById ("feedbackHeader");
		title.innerHTML = "Review User Feedback";
	
		for (var i = 0; i < feedbackStore.length; i++) { // For loop to loop through array and display all feedback from users
			
			// Element Creation
			var divCreated = document.createElement ("DIV");
			
			// Attribute set and class set
			divCreated.setAttribute ("id", "className");
			divCreated.id = "feedback"+i;
			divCreated.className = "fbContainer";
			
			// Content Creation
			divCreated.innerHTML = "<p style = 'font-size: 1em' >By: "
										+"</br>"
										+"<strong>" + feedbackStore [i].name + " (" +feedbackStore [i].accountType +")" +"</strong>"
									+"<br/> Subject: "
										+"</br>"
										+"<strong>" +feedbackStore [i].subjectName +"</strong>"
									+"<br/> Category: "
										+"</br>"
										+"<strong>" +feedbackStore [i].category +"</strong>"
									+"<br/> Feedback:</p> "
										+"<p>"
										+"<strong>" +feedbackStore [i].feedback +"</strong></p><br/>";
			
			//appendChild
			var yes = document.getElementById ("review");
			yes.appendChild (divCreated);
			
		}
		
		if (feedbackStore.length == 0) {
			alert ("No Feedback is present");
		}
	}
		
		
}

function deleteFeedback (selectedDiv) {
	
		var feedbackId = selectedDiv.id;
		// Getting the "Index" of the feedback Id
		var feedbackNo = feedbackId.substr(feedbackId.length - 1);
		
		if (feedbackNo === "0") {
		feedbackNo = divindexNo.substr(divindexNo.length - 2);
		}
	
		if (feedbackNo === "00") {
		feedbackNo = divindexNo.substr(divindexNo.length - 3);
		}
		
		var deleteConfirm = confirm ("Are you sure you want to delete your feedback? This is a irreversible process");
			if (deleteConfirm == false) {
				return false;
			}
			// Actual Deleting Process occurs here
			if (deleteConfirm) {
				feedbackStore.splice (feedbackNo,1);
				// Getting updated object Stringified back into localStorage
				localStorage.setItem ("feedbackInfo", JSON.stringify (feedbackStore));
				alert ("Feedback Successfully Removed");
				location.reload();
				return true;	
			}
			
}
	
	


function updateFeedback () {
	
		var updateConfirm = confirm ("Do you want to update your Feedback?");
		
		if (updateConfirm == false) {
			alert ("No Changes have been made");
			location.reload();
			return false;
		}
			
		if (updateConfirm) {
			
					
		}
			
		
	
}

function feedbackFill () {
	
	// variable intialization from localStorage
	
	var admin = localStorage.getItem("Superuser");
	
	if (admin == null) {
		admin = [];
	}
	else {
		admin = JSON.parse (admin);
	}
	
	var cUser = localStorage.getItem ("currentUser");
	
	if (cUser === "null") {
		cUser = [];
	}
	else {
		cUser = JSON.parse (cUser);
	}
	
	var userInfo = localStorage.getItem ("userInformation");
	
	if (userInfo == null) {
		userInfo = [];
	}
	else {
		userInfo = JSON.parse(userInfo);
	}
	
	var index = localStorage.getItem ("feedbackIndex"); 
			
	if (index === null) {
		index = [];
	}
	else {
		index = JSON.parse(index);
	}
	
	//
	
	if (cUser !== "Admin") { // If User is not an administrator
		
		if (cUser.length !== 0) { // If user is logged in
				
				if (index.length !== 0) { // If user has submitted feedback before
					var indexNo = index[0].indexValue;
					var nameInp = document.getElementById ("name");
					var emailInp = document.getElementById ("emailfield");
					var categoryInp = document.getElementById ("feedbackCat");
					var subjectInp = document.getElementById ("eventDes");
					var feedbackInp = document.getElementById ("feedbackBox");
							
					var feedbackIndex = feedbackStore [indexNo];
							
					nameInp.value = feedbackIndex.name;
					emailInp.value = feedbackIndex.email;
					categoryInp.value = feedbackIndex.category;
					subjectInp.value = feedbackIndex.subjectName;
					feedbackInp.value = feedbackIndex.feedback;
				}
				else { // If user is logged in, but has not submitted feedback before - Fill in User's Email
					var userIndex = cUser;
					var emailInp = document.getElementById ("emailfield");
					var currentuserEmail = userInfo[userIndex].email;
					emailInp.value = currentuserEmail;
				}
		}
		else { // If user is not Logged in
			
			if (index.length !== 0) { // if User has submitted feedback before
					var indexNo = index[0].indexValue;
					var nameInp = document.getElementById ("name");
					var emailInp = document.getElementById ("emailfield");
					var categoryInp = document.getElementById ("feedbackCat");
					var subjectInp = document.getElementById ("eventDes");
					var feedbackInp = document.getElementById ("feedbackBox");
							
					var feedbackIndex = feedbackStore [indexNo];
							
					nameInp.value = feedbackIndex.name;
					emailInp.value = feedbackIndex.email;
					categoryInp.value = feedbackIndex.category;
					subjectInp.value = feedbackIndex.subjectName;
					feedbackInp.value = feedbackIndex.feedback;
			}
		}
	}
	else if (cUser === "Admin"){ // If user is an administrator
		window.location.href = "feedback_review.html"; // Redirect User to admin page
	}
}

function indexStore (selectedDiv) { // Function to store the number of the div users want to update or delete
	var divindexNo = selectedDiv.id;
	var feedbackNo = divindexNo.substr(divindexNo.length - 1);
	
	if (feedbackNo === "0") {
		feedbackNo = divindexNo.substr(divindexNo.length - 2);
	}
	
	if (feedbackNo === "00") {
		feedbackNo = divindexNo.substr(divindexNo.length - 3);
	}
	
	var obj = {"indexValue" : feedbackNo};
	feedbackValue.splice (0,1,obj);
	localStorage.setItem ("feedbackIndex", JSON.stringify (feedbackValue));
	window.location.href = "feedback.html";	
}

function emailValidate () { // Function to validate Guests email addresses and display relevant feedback
	var email = document.getElementById("emailCheck");
	
	if (email.value === "") { //Checking to see if email field is empty
		alert("No email Entered");
		return;
	}
	
	for (var i =0; i<feedbackStore.length; i++) { // For loop to loop through feedbackStore array 
		var emailFound = false;
		
		if (feedbackStore[i].username === "guest") { // Checking to see if user is guest
			
			if (email.value === feedbackStore[i].email) { // Checking user email input against email stored in array
				
				var email = document.getElementById("emailCheck");
				var checkButton = document.getElementById("emailSubmit");
				email.style.display = "none";
				checkButton.style.display = "none";
				
				emailFound = true;
				
				// Element Creation
				var divCreated = document.createElement ("DIV");
				
				// Attribute set and class set
				divCreated.setAttribute ("id", "className");
				divCreated.id = "feedback"+i;
				divCreated.className = "fbContainer";
				
				// Content Creation
				divCreated.innerHTML = "<p style = 'font-size: 1.2em' >By: "
											+"<strong>" + feedbackStore [i].name +"</strong>"
										+"<br/> Subject: "
											+"<strong>" +feedbackStore [i].subjectName +"</strong>"
										+"<br/> Category: "
											+"<strong>" +feedbackStore [i].category +"</strong></p><br/>"
										+"<input type = 'button' value = 'Update Feedback' style = 'padding:10px' onclick = 'indexStore (this.parentNode)'/>"
										+"&nbsp;&nbsp;&nbsp"
										+"<input type = 'button' value = 'Delete Feedback' style = 'padding:10px' onclick = 'deleteFeedback (this.parentNode)'/>";
				
				//appendChild
				var yes = document.getElementById ("review");
				yes.appendChild (divCreated);
			}
		}
	}
	
}


